<?php
require 'mail_helper.php';

$sent = sendMail('rj.ramos564266@gmail.com', 'Test Email from Subportal', '<b>This is a test</b>', 'This is a test');
echo $sent ? 'EMAIL SENT SUCCESSFULLY' : 'EMAIL FAILED';
?>
