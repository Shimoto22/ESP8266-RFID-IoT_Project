<?php
require 'database.php';

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $name = $_POST['name'];
    $gender = $_POST['gender'];
    $subdivision_name = $_POST['subdivision_name'];
    $address = $_POST['address'];
    $username = $_POST['username'];
    $password = password_hash($_POST['password'], PASSWORD_DEFAULT);

    $pdo = Database::connect();
    $stmt = $pdo->prepare("INSERT INTO admin_accounts (name, gender, subdivision_name, address, username, password) VALUES (?, ?, ?, ?, ?, ?)");
    $stmt->execute([$name, $gender, $subdivision_name, $address, $username, $password]);

    Database::disconnect();

    header("Location: login.php?success=1");
    exit();
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Create Admin Account</title>
    <link href="css/bootstrap.min.css" rel="stylesheet">
    <style>
        body {
            background: linear-gradient(135deg, #4bc5ee, #1a73e8);
            height: 100vh;
            display: flex;
            justify-content: center;
            align-items: center;
            font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
        }
        .card {
            border-radius: 15px;
            box-shadow: 0px 8px 20px rgba(0,0,0,0.2);
            padding: 30px;
            width: 400px;
        }
        .form-control {
            border-radius: 10px;
        }
        .btn-outline-custom {
            background: white;
            color: #1a73e8;
            border: 2px solid #1a73e8;
            border-radius: 10px;
            transition: 0.3s;
            font-weight: 600;
        }
        .btn-outline-custom:hover {
            background: #1a73e8;
            color: white;
        }
    </style>
</head>
<body>
    <div class="card">
        <h3 class="text-center mb-4">🧩 Create Admin Account</h3>

        <form method="POST" action="">
            <div class="mb-3"><input type="text" name="name" class="form-control" placeholder="Full Name" required></div>
            <div class="mb-3">
                <select name="gender" class="form-control" required>
                    <option value="">Select Gender</option>
                    <option value="Male">Male</option>
                    <option value="Female">Female</option>
                </select>
            </div>
            <div class="mb-3"><input type="text" name="subdivision_name" class="form-control" placeholder="Subdivision Name" required></div>
            <div class="mb-3"><input type="text" name="address" class="form-control" placeholder="Address" required></div>
            <div class="mb-3"><input type="text" name="username" class="form-control" placeholder="Username" required></div>
            <div class="mb-3"><input type="password" name="password" class="form-control" placeholder="Password" required></div>

            <button type="submit" class="btn btn-outline-custom w-100 mb-2">Create Account</button>
        </form>

        <a href="login.php" class="btn btn-outline-custom w-100">🔑 Back to Login</a>
    </div>
</body>
</html>
