<?php
require 'database.php';

$id = null;
if (!empty($_GET['id'])) {
    $id = $_REQUEST['id'];
}

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $name = $_POST['name'];
    $gender = $_POST['gender'];
    $email = $_POST['email'];
    $mobile = $_POST['mobile'];
    $address = $_POST['address'];
    $user_type = $_POST['user_type'];

    $pdo = Database::connect();
    $pdo->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
    $sql = "UPDATE user_data 
            SET name = ?, gender = ?, email = ?, mobile = ?, address = ?, user_type = ?
            WHERE id = ?";
    $q = $pdo->prepare($sql);
    $q->execute([$name, $gender, $email, $mobile, $address, $user_type, $id]);
    Database::disconnect();

    header("Location: user data.php");
    exit();
}
?>
