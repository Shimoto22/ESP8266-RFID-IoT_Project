-- phpMyAdmin SQL Dump
-- version 5.2.1
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Oct 29, 2025 at 02:37 AM
-- Server version: 10.4.32-MariaDB
-- PHP Version: 8.2.12

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `nodemcu_rfid_iot_projects`
--

-- --------------------------------------------------------

--
-- Table structure for table `admin_accounts`
--

CREATE TABLE `admin_accounts` (
  `id` int(11) NOT NULL,
  `name` varchar(100) NOT NULL,
  `gender` varchar(10) DEFAULT NULL,
  `subdivision_name` varchar(100) NOT NULL,
  `address` varchar(255) NOT NULL,
  `username` varchar(50) NOT NULL,
  `password` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `admin_accounts`
--

INSERT INTO `admin_accounts` (`id`, `name`, `gender`, `subdivision_name`, `address`, `username`, `password`) VALUES
(1, 'RON JOSEPH AMPARO RAMOS', 'Male', 'Loreland ', 'Blck 1 Lot 1 loreland', 'admin2', '$2y$10$ukz24LJR56rUSlDGa2p5NeHjAQIN1IGGu4YgWht41u8.EXtOmPNSm'),
(3, 'Rhean', 'Female', 'Grand Tipolo', 'Blck 1 Lot 1 loreland, Rizal', 'admin1', '$2y$10$ZMdkQCXTYLa8E1/zT90WxuTAhCjjBSbkz/9s/hoglG0iKZN2PHvhy'),
(4, 'ron', 'Male', 'Grand Tipolo', 'Blck 1 Lot 1 loreland', 'admin', '$2y$10$9Jla2RG2O1EqzI55FQY5nOrA.BErXw7siPAfTxOYm1sNmk497wmcy'),
(5, 'Jonald', 'Male', 'Pines City Royale Subdivision', 'Blck 1 Lot 1 loreland, Rizal', 'admin12', '$2y$10$.YTe7fOwLDqW6IpeXMz7hOsaTV1YMAmzcFS0ZXWbPIRA2OGn8qgJu');

-- --------------------------------------------------------

--
-- Table structure for table `log_records`
--

CREATE TABLE `log_records` (
  `id` int(11) NOT NULL,
  `card_id` varchar(100) NOT NULL,
  `name` varchar(100) NOT NULL,
  `scan_date` datetime NOT NULL,
  `admin_id` int(11) NOT NULL DEFAULT 1
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `log_records`
--

INSERT INTO `log_records` (`id`, `card_id`, `name`, `scan_date`, `admin_id`) VALUES
(1, '11ABD8A9', 'JJK', '2025-10-29 04:51:16', 1),
(2, '11ABD8A9', 'JJK', '2025-10-29 04:51:23', 1),
(3, '11ABD8A9', 'KKK', '2025-10-29 09:24:43', 1),
(4, '11ABD8A9', 'KKK', '2025-10-29 09:28:50', 1),
(5, '11ABD8A9', 'KKK', '2025-10-29 09:31:20', 1),
(6, '11ABD8A9', 'KKK', '2025-10-29 09:31:29', 1),
(7, '11ABD8A9', 'LLL', '2025-10-29 09:34:51', 1),
(8, '11ABD8A9', 'LLL', '2025-10-29 09:35:42', 1),
(9, '11ABD8A9', 'LLL', '2025-10-29 09:36:56', 1);

-- --------------------------------------------------------

--
-- Table structure for table `user_data`
--

CREATE TABLE `user_data` (
  `name` varchar(100) NOT NULL,
  `id` varchar(100) NOT NULL,
  `admin_id` int(11) NOT NULL DEFAULT 1,
  `gender` varchar(100) NOT NULL,
  `email` varchar(100) NOT NULL,
  `mobile` varchar(100) NOT NULL,
  `address` varchar(255) DEFAULT NULL,
  `user_type` varchar(100) DEFAULT NULL,
  `daily_count` int(11) DEFAULT 0,
  `last_used` date DEFAULT NULL,
  `is_locked` tinyint(1) DEFAULT 0,
  `scan_count` int(11) DEFAULT 0,
  `locked` tinyint(1) DEFAULT 0,
  `last_reset` date DEFAULT NULL,
  `last_email_sent` datetime DEFAULT NULL,
  `uid` varchar(50) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1 COLLATE=latin1_swedish_ci;

--
-- Dumping data for table `user_data`
--

INSERT INTO `user_data` (`name`, `id`, `admin_id`, `gender`, `email`, `mobile`, `address`, `user_type`, `daily_count`, `last_used`, `is_locked`, `scan_count`, `locked`, `last_reset`, `last_email_sent`, `uid`) VALUES
('RRL', '023FA8AB', 1, 'Female', 'rj.ramos564266@gmail.com', '09636342940', 'Blck 2 lot 2', 'Visitor', 0, '2025-10-29', 0, 0, 0, NULL, NULL, NULL),
('LLL', '11ABD8A9', 1, 'Female', 'rj.ramos564266@gmail.com', '09510157832', 'LORELAND', 'Visitor', 2, '2025-10-29', 0, 0, 0, NULL, NULL, '123'),
('RON JOSEPH AMPARO RAMOS', '510DD3A9', 1, 'Male', 'rj.ramos564266@gmail.com', '09510157832', NULL, NULL, 0, '2025-10-29', 0, 0, 0, NULL, NULL, NULL),
('RON JOSEPH AMPARO RAMOS', 'C382C527', 1, 'Male', 'rj.ramos564266@gmail.com', '09510157832', NULL, NULL, 0, '2025-10-29', 0, 0, 0, NULL, NULL, NULL);

--
-- Indexes for dumped tables
--

--
-- Indexes for table `admin_accounts`
--
ALTER TABLE `admin_accounts`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `username` (`username`);

--
-- Indexes for table `log_records`
--
ALTER TABLE `log_records`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `user_data`
--
ALTER TABLE `user_data`
  ADD PRIMARY KEY (`id`),
  ADD KEY `fk_user_data_admin` (`admin_id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `admin_accounts`
--
ALTER TABLE `admin_accounts`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=6;

--
-- AUTO_INCREMENT for table `log_records`
--
ALTER TABLE `log_records`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=10;

--
-- Constraints for dumped tables
--

--
-- Constraints for table `user_data`
--
ALTER TABLE `user_data`
  ADD CONSTRAINT `fk_user_data_admin` FOREIGN KEY (`admin_id`) REFERENCES `admin_accounts` (`id`);
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
