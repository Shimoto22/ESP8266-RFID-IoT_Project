<?php
session_start();
if (!isset($_SESSION['username'])) {
    header("Location: login.php");
    exit();
}

require 'database.php';
require 'mail_helper.php'; // include email function

$id = $_GET['id'] ?? null;
$pdo = Database::connect();
$pdo->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);

// Fetch user by ID
$sql = "SELECT * FROM user_data WHERE id = ?";
$q = $pdo->prepare($sql);
$q->execute([$id]);
$data = $q->fetch(PDO::FETCH_ASSOC);

$msg = "";
$msg_type = "danger";
$icon = "";

if ($data && $data['name'] != null) {
    $today = date("Y-m-d");

    if (!isset($data['daily_count'])) $data['daily_count'] = 0;
    if (!isset($data['last_used'])) $data['last_used'] = $today;
    if (!isset($data['is_locked'])) $data['is_locked'] = 0;

    if ($data['is_locked'] == 1) {
        $msg = "🔒 ACCESS DENIED - This card is locked by Admin.";
        $msg_type = "danger";
        $icon = "<i class='bi bi-lock-fill text-danger' style='font-size:1.5rem;'></i>";

        // send email
        if (!empty($data['email'])) {
            $subject = "Access Denied - Card Locked";
            $body = "
                <h2>Access Denied</h2>
                <p>Hello <b>{$data['name']}</b>,</p>
                <p>Your RFID card (ID: {$data['id']}) is currently <b>locked by the Admin</b>. 
                Please contact the administrator for assistance.</p>
                <p><b>Address:</b> " . ($data['address'] ?? '--------') . "</p>
                <p><b>User Type:</b> " . ($data['user_type'] ?? '--------') . "</p>
                <p>Time: " . date("Y-m-d H:i:s") . "</p>
                <br><b>- Subdivision Portal System</b>
            ";
            sendMail($data['email'], $subject, $body);
        }

    } else {
        // reset daily count if new day
        if ($data['last_used'] != $today) {
            $data['daily_count'] = 0;
            $sql_reset = "UPDATE user_data SET daily_count=0, last_used=? WHERE id=?";
            $q_reset = $pdo->prepare($sql_reset);
            $q_reset->execute([$today, $id]);
        }

        if ($data['daily_count'] < 10) {
            $new_count = $data['daily_count'] + 1;
            $sql_update = "UPDATE user_data SET daily_count=?, last_used=? WHERE id=?";
            $q_update = $pdo->prepare($sql_update);
            $q_update->execute([$new_count, $today, $id]);

            $msg = "✅ ACCESS GRANTED — Welcome, <b>" . htmlspecialchars($data['name']) . "</b>! (Usage $new_count / 10 today)";
            $msg_type = "success";
            $icon = "<i class='bi bi-unlock-fill text-success' style='font-size:1.5rem;'></i>";

            // log scan
            $sql_log = "INSERT INTO log_records (card_id, name, scan_date) VALUES (?, ?, NOW())";
            $q_log = $pdo->prepare($sql_log);
            $q_log->execute([$id, $data['name']]);

            // send email
            if (!empty($data['email'])) {
                $subject = "Access Granted - Subdivision Portal";
                $body = "
                    <h2>Access Granted</h2>
                    <p>Hello <b>{$data['name']}</b>,</p>
                    <p>Your RFID card has been successfully used at the gate.</p>
                    <p><b>Usage:</b> $new_count / 10 today</p>
                    <p><b>Address:</b> " . ($data['address'] ?? '--------') . "</p>
                    <p><b>User Type:</b> " . ($data['user_type'] ?? '--------') . "</p>
                    <p>Time: " . date("Y-m-d H:i:s") . "</p>
                    <br><b>- Subdivision Portal System</b>
                ";
                sendMail($data['email'], $subject, $body);
            }

        } else {
            // max reached
            $sql_lock = "UPDATE user_data SET is_locked=1 WHERE id=?";
            $q_lock = $pdo->prepare($sql_lock);
            $q_lock->execute([$id]);

            $msg = "❌ Max 10 uses reached today! Your ID is now LOCKED.";
            $msg_type = "danger";
            $icon = "<i class='bi bi-lock-fill text-danger' style='font-size:1.5rem;'></i>";

            if (!empty($data['email'])) {
                $subject = "Card Locked - Max Usage Reached";
                $body = "
                    <h2>Card Locked</h2>
                    <p>Hello <b>{$data['name']}</b>,</p>
                    <p>Your RFID card has reached the maximum of <b>10 uses today</b> 
                    and is now locked automatically.</p>
                    <p><b>Address:</b> " . ($data['address'] ?? '--------') . "</p>
                    <p><b>User Type:</b> " . ($data['user_type'] ?? '--------') . "</p>
                    <p>Time: " . date("Y-m-d H:i:s") . "</p>
                    <br><b>- Subdivision Portal System</b>
                ";
                sendMail($data['email'], $subject, $body);
            }

            $data['is_locked'] = 1;
        }
    }
} else {
    $msg = "❌ The ID of your Card / KeyChain is not registered!";
    $icon = "<i class='bi bi-exclamation-triangle-fill text-danger' style='font-size:1.5rem;'></i>";
    $data = [
        'id' => $id,
        'name' => "--------",
        'gender' => "--------",
        'email' => "--------",
        'mobile' => "--------",
        'address' => "--------",
        'user_type' => "--------"
    ];
}

Database::disconnect();
?>

<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="utf-8">
<meta name="viewport" content="width=device-width, initial-scale=1">
<title>Read Tag - NodeMCU ESP8266 Project</title>
<link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/css/bootstrap.min.css" rel="stylesheet">
<link href="https://cdn.jsdelivr.net/npm/bootstrap-icons/font/bootstrap-icons.css" rel="stylesheet">
<style>
    body { font-family: Arial, sans-serif; }
    #sidebar { position: fixed; top:0; left:-250px; width:250px; height:100%; background:#0d6efd; padding-top:60px; transition:0.3s; z-index:999;}
    #sidebar a { display:block; color:white; padding:15px 20px; text-decoration:none; }
    #sidebar a:hover { background:#0b5ed7; }
    #sidebar .logout { color:#ffc107; }
    #sidebar a.active { background:#0b5ed7; font-weight:bold; }
    #sidebar .subdivision-info { padding:15px 20px; color:#fff; border-bottom:1px solid rgba(255,255,255,0.3); margin-bottom:10px; font-size:0.9rem;}
    #overlay { position:fixed; top:0; left:0; width:0; height:100%; background:rgba(0,0,0,0.5); transition:0.3s; z-index:998;}
    #content { transition:margin-left 0.3s; padding:20px; }
    table th, table td { vertical-align: middle; text-align:center; }
</style>
</head>
<body>
<nav class="navbar navbar-dark bg-primary shadow p-3">
    <span class="menu-btn" onclick="toggleSidebar()" id="menuIcon"><i class="bi bi-list"></i></span>
    <a class="navbar-brand ms-3" href="home.php">SUBDIVISION PORTAL</a>
</nav>

<div id="sidebar">
    <div class="subdivision-info">
        <?php if(isset($_SESSION['subdivision_name']) && isset($_SESSION['address'])): ?>
            <strong><?php echo htmlspecialchars($_SESSION['subdivision_name']); ?></strong><br>
            <small><?php echo htmlspecialchars($_SESSION['address']); ?></small>
        <?php else: ?>
            <strong>Welcome!</strong>
        <?php endif; ?>
    </div>
    <a href="home.php"><i class="bi bi-house-door"></i> Home</a>
    <a href="log_record.php"><i class="bi bi-clipboard-data"></i> Log Record</a>
    <a href="user data.php"><i class="bi bi-people-fill"></i> User Data</a>
    <a href="registration.php"><i class="bi bi-person-plus-fill"></i> Registration</a>
    <a href="read tag.php" class="active"><i class="bi bi-upc-scan"></i> Read Tag</a>
    <a href="logout.php" class="logout"><i class="bi bi-box-arrow-right"></i> Logout</a>
</div>

<div id="overlay" onclick="toggleSidebar()"></div>

<div id="content" class="container mt-4">
    <div class="alert alert-<?php echo $msg_type; ?> text-center fw-bold shadow" role="alert" style="font-size:18px;">
        <?php echo $icon . " " . $msg; ?>
    </div>

    <div class="card shadow mt-4">
        <div class="card-header bg-white text-dark text-center fw-bold">
            User Data <?php echo $icon; ?>
        </div>
        <div class="card-body">
            <table class="table table-striped table-bordered text-center">
                <tbody>
                    <tr><td><b>ID</b></td><td><?php echo $data['id']; ?></td></tr>
                    <tr><td><b>Name</b></td><td><?php echo $data['name']; ?></td></tr>
                    <tr><td><b>Gender</b></td><td><?php echo $data['gender']; ?></td></tr>
                    <tr><td><b>Email</b></td><td><?php echo $data['email']; ?></td></tr>
                    <tr><td><b>Mobile</b></td><td><?php echo $data['mobile']; ?></td></tr>
                    <tr><td><b>Address</b></td><td><?php echo $data['address']; ?></td></tr>
                    <tr><td><b>User Type</b></td><td><?php echo $data['user_type']; ?></td></tr>
                </tbody>
            </table>

            <?php if (isset($data['is_locked']) && $data['is_locked'] == 1): ?>
            <div class="alert alert-danger text-center fw-bold mt-3">
                🔒 CARD IS LOCKED — ACCESS DENIED
            </div>
            <div class="text-center mt-2">
                <a href="unlock.php?id=<?php echo $data['id']; ?>" class="btn btn-warning btn-lg">🔓 Unlock Card</a>
            </div>
            <?php endif; ?>

            <div class="text-center mt-3">
                <a href="read tag.php" class="btn btn-primary btn-lg">🔁 Scan Again</a>
            </div>
        </div>
    </div>
</div>

<script>
function toggleSidebar() {
    let sidebar = document.getElementById("sidebar");
    let overlay = document.getElementById("overlay");
    let menuIcon = document.getElementById("menuIcon");

    if (sidebar.style.left === "0px") {
        sidebar.style.left = "-250px";
        overlay.style.width = "0";
        menuIcon.innerHTML = '<i class="bi bi-list"></i>';
    } else {
        sidebar.style.left = "0";
        overlay.style.width = "100%";
        menuIcon.innerHTML = '<i class="bi bi-x-lg"></i>';
    }
}
</script>

<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>
