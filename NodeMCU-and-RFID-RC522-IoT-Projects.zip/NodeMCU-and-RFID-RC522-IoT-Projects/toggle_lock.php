<?php
require 'database.php';

if (isset($_GET['id']) && isset($_GET['action'])) {
    $id = $_GET['id'];
    $action = $_GET['action'];

    $pdo = Database::connect();

    if ($action == 'lock') {
        $sql = "UPDATE user_data SET locked = 1 WHERE id = ?";
        $pdo->prepare($sql)->execute([$id]);
        header("Location: user data.php?status=locked");
    } elseif ($action == 'unlock') {
        $sql = "UPDATE user_data SET locked = 0 WHERE id = ?";
        $pdo->prepare($sql)->execute([$id]);
        header("Location: user data.php?status=unlocked");
    }

    Database::disconnect();
    exit();
}
?>
<!-- table_the_iot_projects -->
 <!-- user_data -->