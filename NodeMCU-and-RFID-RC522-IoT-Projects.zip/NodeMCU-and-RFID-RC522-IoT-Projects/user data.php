<?php
session_start();
if (!isset($_SESSION['username'])) {
    header("Location: login.php");
    exit();
}

$Write = "<?php $" . "UIDresult=''; " . "echo $" . "UIDresult;" . " ?>";
file_put_contents('UIDContainer.php', $Write);

require 'database.php';
$pdo = Database::connect();
$pdo->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);

/* 🔁 AUTO RESET DAILY COUNT IF DATE CHANGED */
$today = date("Y-m-d");
$sql_reset = "UPDATE user_data 
              SET daily_count = 0, last_used = ? 
              WHERE last_used IS NULL OR last_used <> ?";
$q_reset = $pdo->prepare($sql_reset);
$q_reset->execute([$today, $today]);
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title>User Data - NodeMCU ESP8266</title>

    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/css/bootstrap.min.css" rel="stylesheet">
    <link href="https://cdn.jsdelivr.net/npm/bootstrap-icons/font/bootstrap-icons.css" rel="stylesheet">

    <style>
        body { font-family: Arial, sans-serif; }
        #sidebar {
            position: fixed;
            top: 0;
            left: -250px;
            height: 100%;
            width: 250px;
            background: #0d6efd;
            padding-top: 60px;
            transition: 0.3s;
            z-index: 999;
        }
        #sidebar a {
            padding: 15px 20px;
            display: block;
            color: white;
            text-decoration: none;
            transition: 0.2s;
        }
        #sidebar a:hover { background: #0b5ed7; }
        #sidebar .logout { color: #ffc107; }
        #sidebar .subdivision-info {
            padding: 15px 20px;
            color: #fff;
            border-bottom: 1px solid rgba(255,255,255,0.3);
            margin-bottom: 10px;
            font-size: 0.9rem;
        }
        #overlay {
            position: fixed;
            top: 0;
            left: 0;
            height: 100%;
            width: 0;
            background: rgba(0, 0, 0, 0.5);
            transition: 0.3s;
            z-index: 998;
        }
        #content { transition: margin-left 0.3s; padding: 20px; }
        .menu-btn { font-size: 28px; cursor: pointer; color: white; }
        .navbar { z-index: 1000; }

        .table th, .table td {
            border: 1px solid #dee2e6;
            padding: 10px;
            vertical-align: middle;
        }
        .table th { background-color: #f8f9fa; text-align: center; }
        .table td { text-align: center; }
        .gender-text { font-weight: bold; color: black; }
    </style>
</head>
<body>
    <nav class="navbar navbar-dark bg-primary shadow p-3">
        <span class="menu-btn" onclick="toggleSidebar()" id="menuIcon"><i class="bi bi-list"></i></span>
        <a class="navbar-brand ms-3" href="home.php">SUBDIVISION PORTAL</a>
    </nav>

    <div id="sidebar">
        <div class="subdivision-info">
            <?php if(isset($_SESSION['subdivision_name']) && isset($_SESSION['address'])): ?>
                <strong><?php echo htmlspecialchars($_SESSION['subdivision_name']); ?></strong><br>
                <small><?php echo htmlspecialchars($_SESSION['address']); ?></small>
            <?php else: ?>
                <strong>Welcome!</strong>
            <?php endif; ?>
        </div>
        <a href="home.php"><i class="bi bi-house-door"></i> Home</a>
        <a href="log_record.php"><i class="bi bi-clipboard-data"></i> Log Record</a>
        <a href="user data.php" class="active"><i class="bi bi-people-fill"></i> User Data</a>
        <a href="registration.php"><i class="bi bi-person-plus-fill"></i> Registration</a>
        <a href="read tag.php"><i class="bi bi-upc-scan"></i> Read Tag</a>
        <a href="logout.php" class="logout"><i class="bi bi-box-arrow-right"></i> Logout</a>
    </div>

    <div id="overlay" onclick="toggleSidebar()"></div>

    <div id="content" class="container mt-4">
        <?php
        if (isset($_GET['msg'])) {
            if ($_GET['msg'] == 'locked') {
                echo '<div class="alert alert-danger text-center fw-bold shadow" role="alert">🔒 Card successfully locked!</div>';
            } elseif ($_GET['msg'] == 'unlocked') {
                echo '<div class="alert alert-success text-center fw-bold shadow" role="alert">🔓 Card successfully unlocked!</div>';
            }
        }
        ?>

        <h2 class="text-center">User Data Table</h2>
        <div class="table-container mt-4">
            <div class="table-responsive">
                <table class="table table-striped table-hover align-middle">
                    <thead>
                        <tr>
                            <th>Name</th>
                            <th>ID</th>
                            <th>Gender</th>
                            <th>Email</th>
                            <th>Mobile Number</th>
                            <!-- 🏠 Added columns -->
                            <th>Address</th>
                            <th>User Type</th>
                            <th>Action</th>
                        </tr>
                    </thead>
                    <tbody>
                    <?php
                    $sql = 'SELECT * FROM user_data ORDER BY name ASC';
                    foreach ($pdo->query($sql) as $row) {
                        echo '<tr>';
                        echo '<td><i class="bi bi-person-circle me-1 text-primary"></i>'. htmlspecialchars($row['name']) . '</td>';
                        echo '<td><span class="badge bg-secondary">'. htmlspecialchars($row['id']) .'</span></td>';
                        echo '<td class="gender-text">'. strtoupper(htmlspecialchars($row['gender'])) .'</td>';
                        echo '<td><a href="mailto:'. htmlspecialchars($row['email']) .'" class="text-decoration-none"><i class="bi bi-envelope-fill me-1 text-danger"></i>'. htmlspecialchars($row['email']) .'</a></td>';
                        echo '<td><a href="tel:'. htmlspecialchars($row['mobile']) .'" class="text-decoration-none"><i class="bi bi-telephone-fill me-1 text-success"></i>'. htmlspecialchars($row['mobile']) .'</a></td>';
                        
                        // 🏠 Added new fields
                        echo '<td>'. htmlspecialchars($row['address']) .'</td>';
                        echo '<td>'. htmlspecialchars($row['user_type']) .'</td>';
                        
                        echo '<td>
                                <a class="btn btn-sm btn-outline-success" href="user data edit page.php?id='.$row['id'].'"><i class="bi bi-pencil-square"></i> Edit</a>
                                <a class="btn btn-sm btn-outline-danger" href="user data delete page.php?id='.$row['id'].'"><i class="bi bi-trash"></i> Delete</a>';
                        
                        if (isset($row['is_locked']) && $row['is_locked'] == 1) {
                            echo ' <a class="btn btn-sm btn-warning" href="unlock.php?id='.$row['id'].'"><i class="bi bi-unlock-fill"></i> Unlock</a>';
                        } else {
                            echo ' <a class="btn btn-sm btn-secondary" href="lock.php?id='.$row['id'].'"><i class="bi bi-lock-fill"></i> Lock</a>';
                        }

                        echo '</td>';
                        echo '</tr>';
                    }
                    Database::disconnect();
                    ?>
                    </tbody>
                </table>
            </div>
        </div>
    </div>

    <script>
        function toggleSidebar() {
            let sidebar = document.getElementById("sidebar");
            let overlay = document.getElementById("overlay");
            let menuIcon = document.getElementById("menuIcon");

            if (sidebar.style.left === "0px") {
                sidebar.style.left = "-250px";
                overlay.style.width = "0";
                menuIcon.innerHTML = '<i class="bi bi-list"></i>';
            } else {
                sidebar.style.left = "0";
                overlay.style.width = "100%";
                menuIcon.innerHTML = '<i class="bi bi-x-lg"></i>';
            }
        }
    </script>

    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/js/bootstrap.bundle.min.js"></script>
        <script>
// 🔁 AUTO CHECK for RFID scans
setInterval(() => {
  fetch("UIDContainer.php?nocache=" + new Date().getTime())
    .then(response => response.text())
    .then(uid => {
      uid = uid.trim();
      if (uid && uid !== "<?php echo isset($lastUID) ? $lastUID : ''; ?>") {
        // ✅ Redirect to Read Tag automatically when a card is scanned
        window.location.href = "read tag.php?uid=" + encodeURIComponent(uid);
      }
    });
}, 200); // check every 2 seconds
</script>
</body>
</html>
<!-- table_the_iot_projects -->
 <!-- user_data -->
