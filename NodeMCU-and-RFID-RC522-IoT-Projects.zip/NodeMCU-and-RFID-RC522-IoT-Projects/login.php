<?php
session_start();
require 'database.php';

// If already logged in, go straight to home
if (isset($_SESSION['username'])) {
    header("Location: home.php");
    exit();
}

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $username = $_POST['username'];
    $password = $_POST['password'];

    $pdo = Database::connect();
    $stmt = $pdo->prepare("SELECT * FROM admin_accounts WHERE username = ?");
    $stmt->execute([$username]);
    $user = $stmt->fetch(PDO::FETCH_ASSOC);
    Database::disconnect();

    if ($user && password_verify($password, $user['password'])) {
        $_SESSION['username'] = $user['username'];
        $_SESSION['subdivision_name'] = $user['subdivision_name'];
        $_SESSION['address'] = $user['address'];
        header("Location: home.php");
        exit();
    } else {
        $error = "Invalid Username or Password!";
    }
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Login</title>
    <link href="css/bootstrap.min.css" rel="stylesheet">
    <style>
        body {
            background: linear-gradient(135deg, #4bc5ee, #1a73e8);
            height: 100vh;
            display: flex;
            justify-content: center;
            align-items: center;
            font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
        }
        .card {
            border-radius: 15px;
            box-shadow: 0px 8px 20px rgba(0,0,0,0.2);
            padding: 30px;
            width: 350px;
        }
        .form-control {
            border-radius: 10px;
        }
        .btn-outline-custom {
            background: white;
            color: #1a73e8;
            border: 2px solid #1a73e8;
            border-radius: 10px;
            transition: 0.3s;
            font-weight: 600;
        }
        .btn-outline-custom:hover {
            background: #1a73e8;
            color: white;
        }
    </style>
</head>
<body>
    <div class="card">
        <h3 class="text-center mb-4">🔒 Secure Login</h3>

        <?php if (isset($_GET['success'])) { ?>
            <div class="alert alert-success text-center">✅ Account created successfully! Please log in.</div>
        <?php } ?>

        <?php if (isset($error)) { ?>
            <div class="alert alert-danger text-center"><?php echo $error; ?></div>
        <?php } ?>

        <form method="POST" action="">
            <div class="mb-3">
                <input type="text" name="username" class="form-control" placeholder="Username" required>
            </div>
            <div class="mb-3">
                <input type="password" name="password" class="form-control" placeholder="Password" required>
            </div>
            <button type="submit" class="btn btn-outline-custom w-100 mb-2">🔑 Login</button>
        </form>

        <a href="register_admin.php" class="btn btn-outline-custom w-100">🧩 Create Admin Account</a>
    </div>
</body>
</html>
