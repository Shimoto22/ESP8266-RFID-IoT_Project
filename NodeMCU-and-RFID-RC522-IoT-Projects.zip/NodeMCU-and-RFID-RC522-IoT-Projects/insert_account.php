<?php
require 'database.php';

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $pdo = Database::connect();

    $username = $_POST['username'];
    $password = $_POST['password'];
    $role = $_POST['role'];
    $subdivision = $_POST['subdivision'];
    $address = $_POST['address'];

    $sql = "INSERT INTO users (username, password, role, subdivision, address)
            VALUES (?, ?, ?, ?, ?)";
    $stmt = $pdo->prepare($sql);
    $stmt->execute([$username, $password, $role, $subdivision, $address]);

    Database::disconnect();
    header("Location: login.php");
    exit();
}
?>
