<?php
// clearUID.php - empties UIDContainer.php to prevent repeated redirects
$Write = "<?php $" . "UIDresult=''; " . "echo $" . "UIDresult;" . " ?>";
file_put_contents('UIDContainer.php', $Write);
echo "CLEARED";
?>
