<?php
// mail_helper.php
use PHPMailer\PHPMailer\PHPMailer;
use PHPMailer\PHPMailer\Exception;

require __DIR__ . '/vendor/autoload.php'; // Composer autoload

function sendMail($to, $subject, $bodyHtml, $bodyText = '') {
    $mail = new PHPMailer(true);
    try {
        // Gmail SMTP
        $mail->isSMTP();
        $mail->Host = 'smtp.gmail.com';
        $mail->SMTPAuth = true;
        $mail->Username = 'rj.ramos564266@gmail.com';      // <-- YOUR GMAIL
        $mail->Password = 'mdgh hbky lwjb jwqn';        // <-- 16-char app password
        $mail->SMTPSecure = 'tls';
        $mail->Port = 587;

        $mail->setFrom('rj.ramos564266@gmail.com', 'Subdivision Portal');
        $mail->addAddress($to);

        $mail->isHTML(true);
        $mail->Subject = $subject;
        $mail->Body    = $bodyHtml;
        $mail->AltBody = $bodyText ?: strip_tags($bodyHtml);

        $mail->send();
        return true;
    } catch (Exception $e) {
        error_log('Mailer Error: ' . $mail->ErrorInfo);
        return false;
    }
}
?>
