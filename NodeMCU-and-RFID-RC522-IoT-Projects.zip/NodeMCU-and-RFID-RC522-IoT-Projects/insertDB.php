<?php
require 'database.php';

if (!empty($_POST)) {
    $name = $_POST['name'];
    $id = $_POST['id'];  // RFID card ID
    $gender = $_POST['gender'];
    $email = $_POST['email'];
    $mobile = $_POST['mobile'];
    $address = $_POST['address'];       // ✅ new
    $user_type = $_POST['user_type'];   // ✅ new
    
    $pdo = Database::connect();
    $pdo->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
    $sql = "INSERT INTO user_data (name, id, gender, email, mobile, address, user_type) VALUES (?, ?, ?, ?, ?, ?, ?)";
    $q = $pdo->prepare($sql);
    $q->execute(array($name, $id, $gender, $email, $mobile, $address, $user_type));

    // Optional log entry
    $sql2 = "INSERT INTO log_records (card_id, name, scan_date) VALUES (?, ?, NOW())";
    $q2 = $pdo->prepare($sql2);
    $q2->execute(array($id, $name));

    Database::disconnect();
    header("Location: user data.php");
}
?>
