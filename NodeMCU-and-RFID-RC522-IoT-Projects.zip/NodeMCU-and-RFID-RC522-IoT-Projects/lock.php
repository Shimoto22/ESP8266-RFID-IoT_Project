<?php
require 'database.php';

if (isset($_GET['id'])) {
    $id = $_GET['id'];

    $pdo = Database::connect();
    $pdo->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);

    // Lock the card
    $sql = "UPDATE user_data SET is_locked = 1 WHERE id = ?";
    $q = $pdo->prepare($sql);
    $q->execute([$id]);

    Database::disconnect();

    // Redirect back with success message
    header("Location: user data.php?msg=locked");
    exit();
} else {
    echo "No ID specified.";
}
?>
<!-- table_the_iot_projects -->
 <!-- user_data -->